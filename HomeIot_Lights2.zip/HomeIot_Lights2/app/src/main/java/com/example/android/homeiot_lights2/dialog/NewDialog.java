package com.example.android.homeiot_lights2.dialog;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.android.homeiot_lights2.MainActivity;
import com.example.android.homeiot_lights2.R;
import com.example.android.homeiot_lights2.model.Lights;

public class NewDialog extends DialogFragment {

    String[] lightsNames;
    Spinner spinner;
    ImageView imageView;
    int currentIndex;
    EditText editText;

    NoticeDialogListener listener;
    //MainActy extends Activity implements Context ,NoticeDialogListener
    // MainActy istanceOf Activity   -> true
    // MainActy istanceOf Context   -> true
    // MainActy istanceOf NoticeDialogListener  -> true


    @Override
    public void onAttach(Context context) { //context = MainActivity.java
        super.onAttach(context);
        listener=(NoticeDialogListener)context;
    }

    public interface NoticeDialogListener{
        public void onDialogPostivieClick(DialogFragment fragment);

    }



    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view =  inflater.inflate(R.layout.content_new_lights, null);
        builder.setView(view);

        lightsNames = getResources().getStringArray(R.array.lights_name);

        spinner = view.findViewById(R.id.spinner);
        imageView = view.findViewById(R.id.imageView);
        editText = view.findViewById(R.id.editText);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity()
                , android.R.layout.simple_spinner_item
                , lightsNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner.setAdapter(adapter);


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Drawable drawable = makeLightsType(position);
                imageView.setImageDrawable(drawable);
                currentIndex=position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });



        builder.setPositiveButton("save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String name = editText.getText().toString();
                if(TextUtils.isEmpty(name)){
                    name = lightsNames[currentIndex];
                }

                Lights lights = new Lights(name, currentIndex);

                listener.onDialogPostivieClick(NewDialog.this);
                //Toast.makeText(getActivity(), lights.toString() , Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getActivity(), lightsNames[currentIndex], Toast.LENGTH_SHORT).show();
            }
        });



 //       builder.setTitle("new Dialog");
 //       builder.setMessage("Hello Dialog");

        return builder.create();
    }



    public Drawable makeLightsType(int index){
        TypedArray images = getResources().obtainTypedArray(R.array.lights_resources);
        Drawable drawable = images.getDrawable(index);
        return drawable;
    }
}
