package com.example.android.homeiot_lights2.model;

public class Lights {

    public static int ID=0;

    private int id;
    private int resourceIndex; // 0, 1 , 2
    private String name;

    public Lights(String name, int resourceIndex){
        this.id = ID++;
        this.name = name;
        this.resourceIndex = resourceIndex;
    }

    public int getId() {
        return id;
    }

    public int getResourceIndex() {
        return resourceIndex;
    }

    public String getName() {
        return name;
    }


    @Override
    public String toString() {
        return " id: "+id + " name: "+name + " resourceIndex: "+resourceIndex;
    }
}
