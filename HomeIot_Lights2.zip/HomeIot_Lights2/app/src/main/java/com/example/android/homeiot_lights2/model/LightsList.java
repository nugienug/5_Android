package com.example.android.homeiot_lights2.model;

import java.util.ArrayList;
import java.util.List;

public class LightsList {

    private List<Lights> lightsList;

    public LightsList(){
        lightsList = new ArrayList<>();
    }

    public List<Lights> getLightsList(){
        return this.lightsList;
    }

    public void addLights(Lights newLights){
        this.lightsList.add(newLights);
    }


}
