package com.example.android.homeiot_lights2;

import android.support.design.widget.FloatingActionButton;

import android.support.design.widget.Snackbar;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.app.AlertDialog;
import android.widget.Toast;

import com.example.android.homeiot_lights2.dialog.NewDialog;
import com.example.android.homeiot_lights2.model.Lights;
import com.example.android.homeiot_lights2.model.LightsList;

public class MainActivity extends AppCompatActivity  implements NewDialog.NoticeDialogListener  {

    FloatingActionButton fab;
    LightsList lightsList;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lightsList = new LightsList();
        lightsList.addLights(new Lights("test", 1));

        fab = findViewById(R.id.floatingActionButton);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {  // to comment - Ctrl + "/"

                NewDialog dialog = new NewDialog();
                dialog.show(getSupportFragmentManager(), "hello");

 //               Toast.makeText(getApplicationContext(), "Hello Toast", Toast.LENGTH_SHORT).show();

//                Snackbar snackbar = Snackbar.make(findViewById(R.id.main), "Hello snackBar", Snackbar.LENGTH_SHORT);
//                snackbar.setAction("Bye", new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        Toast.makeText(getApplicationContext(), "Hello snackBar", Toast.LENGTH_SHORT).show();
//                    }
//                });
//                snackbar.show();

            }
        });
    }

    @Override
    public void onDialogPostivieClick(DialogFragment fragment) {
        Toast.makeText(getApplicationContext(), "Hello fragment", Toast.LENGTH_SHORT).show();
    }
}
